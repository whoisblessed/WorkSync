from typing import Annotated

from fastapi import APIRouter, Depends, status

from app.api.dependencies import (
    get_current_user,
    get_user_with_roles,
    get_schedule_service,
)
from app.models import User as UserModel
from app.models.user import Role
from app.shemas.schedule import (
    Schedule as ScheduleSchema,
    ScheduleCreate as ScheduleCreateSchema,
    ScheduleUpdate as ScheduleUpdateSchema,
)
from app.services import ScheduleService


router = APIRouter(prefix="/schedules", tags=["schedules"])
