from enum import Enum
from datetime import date

from sqlalchemy import String, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db import Base


class SheduleExceptionType(Enum):
    vacation: str = "vacation"
    sick_leave: str = "sick_leave"
    personal: str = "personal"
    business_trip: str = "business_trip"
    

class SheduleException(Base):
    __tablename__ = "shedule_exceptions"
    
    id: Mapped[int] = mapped_column(primary_key=True)
    type: Mapped[SheduleExceptionType] = mapped_column()
    description: Mapped[str | None] = mapped_column(String(500))
    start_date: Mapped[date] = mapped_column()
    end_date: Mapped[date] = mapped_column()
    
    employee_id: Mapped[int] = mapped_column(ForeignKey("employees.id"))

    emplopyee: Mapped["Employee"] = relationship(back_populates="shedule_exceptions")
    