from sqlalchemy import String, Enum, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db import Base


class Employee(Base):
    __tablename__ = "employees"

    id: Mapped[int] = mapped_column(primary_key=True)
    first_name: Mapped[str] = mapped_column(String(255))
    last_name: Mapped[str] = mapped_column(String(255))
    time_zone: Mapped[str] = mapped_column(default="Europe/Moscow")

    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), unique=True)
    team_id: Mapped[int] = mapped_column(ForeignKey("teams.id"))
    shedule_id: Mapped[int] = mapped_column(ForeignKey("sheludes.id"), unique=True)

    user: Mapped["User"] = relationship(back_populates="employee")
    team: Mapped["Team"] = relationship(back_populates="employees")
    shedule: Mapped["Shedule"] = relationship(back_populates="employee", cascade="all, delete-orphan")
    shedule_exceptions: Mapped[list["SheduleException"]] = relationship(back_populates="employee", cascade="all, delete-orphan")